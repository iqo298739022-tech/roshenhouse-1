<?php
/**
 * The main template file
 *
 * @package Financial_Center
 */

get_header();
?>

<main id="primary" class="site-main max-w-7xl mx-auto px-4 py-8">
    <?php
    if (have_posts()) :
        while (have_posts()) :
            the_post();
            ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('bg-white p-6 rounded-3xl border border-slate-200 mb-6 shadow-sm'); ?>>
                <h1 class="text-2xl font-black text-slate-900 mb-3"><?php the_title(); ?></h1>
                <div class="entry-content text-slate-700 leading-relaxed">
                    <?php the_content(); ?>
                </div>
            </article>
            <?php
        endwhile;
        the_posts_navigation();
    else :
        ?>
        <div class="p-8 bg-white rounded-3xl border border-slate-200 text-center text-slate-500">
            <p><?php esc_html_e('لا يوجد محتوى لعرضه حالياً.', 'financial-center'); ?></p>
        </div>
        <?php
    endif;
    ?>
</main>

<?php
get_footer();
