<?php
/**
 * Real-Time Financial Data & News API Handlers for Twelve Data, Tadawul/Sahmk, Benzinga & Polygon
 *
 * @package Financial_Center
 * @version 2.5.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register Admin Settings Page for APIs in WP-Admin
 */
function financial_center_api_settings_menu() {
    add_menu_page(
        __('المركز المالي - مزودي البيانات و APIs', 'financial-center'),
        __('المركز المالي APIs', 'financial-center'),
        'manage_options',
        'financial-center-api-settings',
        'financial_center_api_settings_page',
        'dashicons-chart-line',
        30
    );
}
add_action('admin_menu', 'financial_center_api_settings_menu');

function financial_center_api_settings_page() {
    if (isset($_POST['fc_save_api_settings']) && check_admin_referer('fc_api_settings_nonce')) {
        update_option('fc_api_provider', sanitize_text_field($_POST['fc_api_provider']));
        update_option('fc_twelve_data_key', sanitize_text_field($_POST['fc_twelve_data_key']));
        update_option('fc_benzinga_key', sanitize_text_field($_POST['fc_benzinga_key']));
        update_option('fc_sahmk_key', sanitize_text_field($_POST['fc_sahmk_key']));
        update_option('fc_polygon_key', sanitize_text_field($_POST['fc_polygon_key']));
        update_option('fc_alpha_vantage_key', sanitize_text_field($_POST['fc_alpha_vantage_key']));
        update_option('fc_finnhub_key', sanitize_text_field($_POST['fc_finnhub_key']));
        update_option('fc_cache_duration', absint($_POST['fc_cache_duration']));
        delete_transient('fc_realtime_quotes_cache');
        delete_transient('fc_benzinga_news_cache');
        echo '<div class="notice notice-success is-dismissible"><p>' . __('تم حفظ إعدادات الـ APIs ومسح الكاش بنجاح!', 'financial-center') . '</p></div>';
    }

    $provider = get_option('fc_api_provider', 'twelvedata');
    $twelve_key = get_option('fc_twelve_data_key', '');
    $benzinga_key = get_option('fc_benzinga_key', '');
    $sahmk_key = get_option('fc_sahmk_key', '');
    $polygon_key = get_option('fc_polygon_key', '');
    $alpha_key = get_option('fc_alpha_vantage_key', '');
    $finnhub_key = get_option('fc_finnhub_key', '');
    $cache_time = get_option('fc_cache_duration', 30);
    ?>
    <div class="wrap" dir="rtl" style="font-family: 'Cairo', sans-serif;">
        <h1><?php _e('🏛️ إعدادات مزودي البيانات وربط الـ APIs الحية - المركز المالي', 'financial-center'); ?></h1>
        <p><?php _e('قم بربط مفاتيح Twelve Data (لأسهم تاسي السعودية والسلع)، Benzinga (للأخبار اللحظية)، وسهمك/تداول.', 'financial-center'); ?></p>

        <form method="post" action="">
            <?php wp_nonce_field('fc_api_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="fc_api_provider"><?php _e('المزود النشط للأسعار (Active Quotes Provider)', 'financial-center'); ?></label></th>
                    <td>
                        <select name="fc_api_provider" id="fc_api_provider" style="font-size: 14px; padding: 6px 12px;">
                            <option value="twelvedata" <?php selected($provider, 'twelvedata'); ?>>Twelve Data API (موصى به لأسهم تاسي 🇸🇦 والذهب والسلع والعملات)</option>
                            <option value="tadawul_sahmk" <?php selected($provider, 'tadawul_sahmk'); ?>>بوابة تداول السعودية / سهمك (Tadawul & Sahmk)</option>
                            <option value="polygon" <?php selected($provider, 'polygon'); ?>>Polygon.io API (بث WebSockets للأسهم والعملات)</option>
                            <option value="finnhub" <?php selected($provider, 'finnhub'); ?>>Finnhub Market API</option>
                            <option value="alphavantage" <?php selected($provider, 'alphavantage'); ?>>Alpha Vantage API</option>
                            <option value="free_public" <?php selected($provider, 'free_public'); ?>>CoinGecko & Open Forex (مجاني مدمج بدون مفتاح)</option>
                        </select>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="fc_twelve_data_key"><?php _e('Twelve Data API Key', 'financial-center'); ?></label></th>
                    <td>
                        <input name="fc_twelve_data_key" type="text" id="fc_twelve_data_key" value="<?php echo esc_attr($twelve_key); ?>" class="regular-text" placeholder="e.g. 8b4c2xxxxxxxxxx" />
                        <p class="description">المزود الرئيسي للسوق السعودي والسلع. احصل على مفتاح من <a href="https://twelvedata.com" target="_blank">twelvedata.com</a>.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="fc_benzinga_key"><?php _e('Benzinga News API Key / Token', 'financial-center'); ?></label></th>
                    <td>
                        <input name="fc_benzinga_key" type="text" id="fc_benzinga_key" value="<?php echo esc_attr($benzinga_key); ?>" class="regular-text" placeholder="e.g. bz_xxxxxxxxxx" />
                        <p class="description">مزود الأخبار والتحليلات المالية والتقارير الحية. احصل على مفتاح من <a href="https://www.benzinga.com/apis/" target="_blank">benzinga.com</a>.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="fc_sahmk_key"><?php _e('مفتاح بوابة تداول / سهمك (Sahmk Gateway)', 'financial-center'); ?></label></th>
                    <td>
                        <input name="fc_sahmk_key" type="text" id="fc_sahmk_key" value="<?php echo esc_attr($sahmk_key); ?>" class="regular-text" />
                        <p class="description">مخصص لسحب بيانات الشركات المدرجة في تداول السعودية ومؤشرات القطاعات.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="fc_polygon_key"><?php _e('Polygon.io API Key', 'financial-center'); ?></label></th>
                    <td>
                        <input name="fc_polygon_key" type="text" id="fc_polygon_key" value="<?php echo esc_attr($polygon_key); ?>" class="regular-text" />
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="fc_cache_duration"><?php _e('مدة التخزين المؤقت في الكاش (بالثواني)', 'financial-center'); ?></label></th>
                    <td>
                        <input name="fc_cache_duration" type="number" id="fc_cache_duration" value="<?php echo esc_attr($cache_time); ?>" min="5" max="3600" />
                        <p class="description">يتم تخزين الأسعار تلقائياً عبر WordPress Transients لتفادي أي استهلاك زائد لحدود الباقات المجانية.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(__('حفظ وتفعيل الـ APIs ⚡', 'financial-center'), 'primary', 'fc_save_api_settings'); ?>
        </form>
    </div>
    <?php
}

/**
 * Fetch Live Quotes from Twelve Data, Polygon, or Free Public APIs with Caching
 */
function financial_center_fetch_live_quotes() {
    $cached = get_transient('fc_realtime_quotes_cache');
    if ($cached !== false) {
        return $cached;
    }

    $provider = get_option('fc_api_provider', 'twelvedata');
    $cache_time = get_option('fc_cache_duration', 30);
    $quotes = array();

    // 1. Twelve Data API (Saudi Tadawul + Commodities + Forex + Crypto)
    if ($provider === 'twelvedata') {
        $api_key = get_option('fc_twelve_data_key', '');
        if (!empty($api_key)) {
            $symbols = 'TASI,2222:TADAWUL,1120:TADAWUL,7010:TADAWUL,2082:TADAWUL,1211:TADAWUL,XAU/USD,BRENT,BTC/USD,ETH/USD,USD/SAR,EUR/USD';
            $response = wp_remote_get("https://api.twelvedata.com/quote?symbol={$symbols}&apikey={$api_key}", array('timeout' => 8));
            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                $body = json_decode(wp_remote_retrieve_body($response), true);
                if (!empty($body)) {
                    $quotes['twelvedata'] = $body;
                }
            }
        }
    }

    // 2. Free Fallback / Public Live Feeds (CoinGecko & Open Forex)
    $crypto_res = wp_remote_get('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,binancecoin,solana,ripple&vs_currencies=usd&include_24hr_change=true', array('timeout' => 6));
    if (!is_wp_error($crypto_res) && wp_remote_retrieve_response_code($crypto_res) === 200) {
        $quotes['crypto'] = json_decode(wp_remote_retrieve_body($crypto_res), true);
    }

    $forex_res = wp_remote_get('https://open.er-api.com/v6/latest/USD', array('timeout' => 6));
    if (!is_wp_error($forex_res) && wp_remote_retrieve_response_code($forex_res) === 200) {
        $forex_body = json_decode(wp_remote_retrieve_body($forex_res), true);
        if (!empty($forex_body['rates'])) {
            $quotes['forex'] = array(
                'SAR' => $forex_body['rates']['SAR'] ?? 3.7508,
                'EUR' => 1 / ($forex_body['rates']['EUR'] ?? 0.923),
                'GBP' => 1 / ($forex_body['rates']['GBP'] ?? 0.786),
                'AED' => $forex_body['rates']['AED'] ?? 3.6725,
            );
        }
    }

    set_transient('fc_realtime_quotes_cache', $quotes, $cache_time);
    return $quotes;
}

/**
 * Fetch Live Financial News from Benzinga News API with Caching
 */
function financial_center_fetch_benzinga_news($count = 10) {
    $cached = get_transient('fc_benzinga_news_cache');
    if ($cached !== false) {
        return $cached;
    }

    $api_key = get_option('fc_benzinga_key', '');
    if (!empty($api_key)) {
        $url = "https://api.benzinga.com/api/v2/news?token={$api_key}&pageSize={$count}&displayOutput=full";
        $response = wp_remote_get($url, array('timeout' => 8));
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $news = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($news) && is_array($news)) {
                set_transient('fc_benzinga_news_cache', $news, 120); // 2 min cache
                return $news;
            }
        }
    }
    return array();
}
