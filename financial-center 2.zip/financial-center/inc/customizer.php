<?php
/**
 * Theme Customizer Settings for Financial Center
 *
 * @package Financial_Center
 */

if (!defined('ABSPATH')) {
    exit;
}

function financial_center_customize_register($wp_customize) {
    // Financial Center Settings Section
    $wp_customize->add_section('financial_center_settings', array(
        'title'    => __('إعدادات المركز المالي', 'financial-center'),
        'priority' => 30,
    ));

    // Live Feed Toggle
    $wp_customize->add_setting('fc_live_simulation', array(
        'default'           => true,
        'sanitize_callback' => 'wp_validate_boolean',
    ));

    $wp_customize->add_control('fc_live_simulation', array(
        'label'    => __('تفعيل البث المباشر ومحاكاة الأسعار اللحظية', 'financial-center'),
        'section'  => 'financial_center_settings',
        'type'     => 'checkbox',
    ));

    // Demo Initial Balance
    $wp_customize->add_setting('fc_initial_balance', array(
        'default'           => 100000,
        'sanitize_callback' => 'absint',
    ));

    $wp_customize->add_control('fc_initial_balance', array(
        'label'    => __('رصيد المحفظة التجريبية الافتراضي ($)', 'financial-center'),
        'section'  => 'financial_center_settings',
        'type'     => 'number',
    ));
}
add_action('customize_register', 'financial_center_customize_register');
