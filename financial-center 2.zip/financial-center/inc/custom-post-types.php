<?php
/**
 * Custom Post Types for Financial Center
 *
 * @package Financial_Center
 */

if (!defined('ABSPATH')) {
    exit;
}

function financial_center_register_cpts() {
    // 1. Market Asset CPT (الأصول والأسهم المالية)
    register_post_type('market_asset', array(
        'labels' => array(
            'name'               => __('الأصول المالية', 'financial-center'),
            'singular_name'      => __('أصل مالي', 'financial-center'),
            'add_new'            => __('إضافة أصل جديد', 'financial-center'),
            'add_new_item'       => __('إضافة أصل مالي جديد', 'financial-center'),
            'edit_item'          => __('تعديل الأصل المالي', 'financial-center'),
            'all_items'          => __('جميع الأصول والأسهم', 'financial-center'),
        ),
        'public'       => true,
        'has_archive'  => true,
        'menu_icon'    => 'dashicons-chart-line',
        'supports'     => array('title', 'editor', 'thumbnail', 'custom-fields'),
        'show_in_rest' => true,
    ));

    // Register Category Taxonomy for Market Assets
    register_taxonomy('market_category', 'market_asset', array(
        'labels' => array(
            'name'          => __('تصنيفات الأسواق', 'financial-center'),
            'singular_name' => __('تصنيف السوق', 'financial-center'),
        ),
        'hierarchical' => true,
        'show_in_rest' => true,
    ));

    // 2. Financial News CPT (الأخبار والتقارير الاقتصادية)
    register_post_type('financial_news', array(
        'labels' => array(
            'name'          => __('الأخبار والتحليلات', 'financial-center'),
            'singular_name' => __('خبر مالي', 'financial-center'),
            'add_new_item'  => __('إضافة خبر مالي جديد', 'financial-center'),
            'all_items'     => __('كافة الأخبار المالية', 'financial-center'),
        ),
        'public'       => true,
        'has_archive'  => true,
        'menu_icon'    => 'dashicons-format-aside',
        'supports'     => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
        'show_in_rest' => true,
    ));

    // 3. Economic Calendar Events CPT (التقويم الاقتصادي)
    register_post_type('economic_event', array(
        'labels' => array(
            'name'          => __('أحداث التقويم الاقتصادي', 'financial-center'),
            'singular_name' => __('حدث اقتصادي', 'financial-center'),
            'all_items'     => __('جميع الأحداث الاقتصادية', 'financial-center'),
        ),
        'public'       => true,
        'menu_icon'    => 'dashicons-calendar-alt',
        'supports'     => array('title', 'custom-fields'),
        'show_in_rest' => true,
    ));
}
add_action('init', 'financial_center_register_cpts');
