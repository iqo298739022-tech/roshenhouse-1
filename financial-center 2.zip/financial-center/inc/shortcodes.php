<?php
/**
 * Shortcodes for Financial Center
 *
 * @package Financial_Center
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Shortcode [financial_center_full_app]
 * Embeds the full interactive financial workstation engine.
 */
function financial_center_full_app_shortcode($atts) {
    ob_start();
    ?>
    <div id="fc-app-container" class="fc-theme-wrapper w-full font-sans antialiased">
        <div id="financial-center-root"></div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('financial_center_full_app', 'financial_center_full_app_shortcode');

/**
 * Shortcode [financial_center_ticker]
 */
function financial_center_ticker_shortcode($atts) {
    ob_start();
    ?>
    <div class="fc-ticker-marquee-embed w-full overflow-hidden bg-[#0F172A] text-white py-2 text-xs">
        <div class="flex items-center gap-4">
            <span class="px-3 py-1 bg-amber-500 text-slate-950 font-bold shrink-0">بث مباشر</span>
            <div class="fc-ticker-stream overflow-x-auto whitespace-nowrap flex gap-4">
                <span>تاسي: 11,516.68 (+0.22%)</span>
                <span>أرامكو: 222.60 (+0.18%)</span>
                <span>الذهب: $2,345.60 (+0.53%)</span>
                <span>برنت: $83.45 (-0.43%)</span>
                <span>بيتكوين: $66,854.20 (+1.83%)</span>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('financial_center_ticker', 'financial_center_ticker_shortcode');
