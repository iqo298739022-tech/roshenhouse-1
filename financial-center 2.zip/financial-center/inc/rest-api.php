<?php
/**
 * REST API Endpoints for Financial Center Theme
 *
 * @package Financial_Center
 */

if (!defined('ABSPATH')) {
    exit;
}

function financial_center_register_rest_routes() {
    register_rest_route('financial-center/v1', '/quotes', array(
        'methods'  => 'GET',
        'callback' => 'financial_center_get_quotes',
        'permission_callback' => '__return_true',
    ));
}
add_action('rest_api_init', 'financial_center_register_rest_routes');

function financial_center_get_quotes($request) {
    // Return sample quotes or live queried CPTs
    $quotes = array(
        array('id' => 'tasi', 'symbol' => 'TASI', 'nameAr' => 'المؤشر العام السعودي', 'price' => 11516.68, 'change' => 25.74, 'changePercent' => 0.22),
        array('id' => 'gold', 'symbol' => 'XAU/USD', 'nameAr' => 'الذهب', 'price' => 2345.60, 'change' => 12.45, 'changePercent' => 0.53),
        array('id' => 'brent', 'symbol' => 'BRENT', 'nameAr' => 'خام برنت', 'price' => 83.45, 'change' => -0.36, 'changePercent' => -0.43),
        array('id' => 'btc', 'symbol' => 'BTC/USD', 'nameAr' => 'بيتكوين', 'price' => 66854.20, 'change' => 1203.45, 'changePercent' => 1.83),
        array('id' => 'aramco', 'symbol' => '2222.SR', 'nameAr' => 'أرامكو السعودية', 'price' => 222.60, 'change' => 0.40, 'changePercent' => 0.18),
    );

    return rest_ensure_response(array(
        'success' => true,
        'timestamp' => time(),
        'quotes' => $quotes,
    ));
}
