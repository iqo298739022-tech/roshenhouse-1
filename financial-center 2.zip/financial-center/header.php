<?php
/**
 * The header for Financial Center theme
 *
 * @package Financial_Center
 */

if (!defined('ABSPATH')) {
    exit;
}
?><!doctype html>
<html <?php language_attributes(); ?> dir="<?php echo is_rtl() ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>

<body <?php body_class('bg-[#F8FAFC] text-slate-900 antialiased'); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site min-h-screen flex flex-col font-sans">
    
    <!-- Top Bar & Navbar will be loaded or rendered -->
    <header class="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-sm">
        
        <!-- Utility Bar -->
        <div class="bg-[#0F172A] border-b border-slate-800 px-4 lg:px-8 py-2 text-xs text-slate-300">
            <div class="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
                
                <div class="flex items-center gap-3">
                    <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-bold">
                        <span class="w-2 h-2 rounded-full bg-emerald-400 live-dot-green"></span>
                        <span><?php esc_html_e('المركز المالي • بث مباشر للأسعار والصفقات اللحظية', 'financial-center'); ?></span>
                    </div>

                    <div class="hidden sm:inline-flex items-center gap-1.5 text-slate-400">
                        <span><?php esc_html_e('🇸🇦 السوق المالي السعودي (تداول)', 'financial-center'); ?></span>
                    </div>
                </div>

                <div class="flex items-center gap-3">
                    <!-- Search Trigger -->
                    <div class="fc-search-trigger relative flex items-center bg-slate-900 text-slate-300 border border-slate-700 rounded-lg px-3 py-1.5 cursor-pointer text-xs">
                        <i data-lucide="search" class="w-3.5 h-3.5 ml-1.5 text-slate-400"></i>
                        <span><?php esc_html_e('بحث سريع (⌘K)...', 'financial-center'); ?></span>
                    </div>

                    <!-- Balance Pill -->
                    <div class="fc-portfolio-pill flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/15 text-amber-300 border border-amber-500/30 text-xs font-bold font-mono">
                        <i data-lucide="wallet" class="w-3.5 h-3.5 text-amber-400"></i>
                        <span id="fc-demo-balance">$100,000.00</span>
                    </div>
                </div>

            </div>
        </div>

        <!-- Main Navigation Bar -->
        <div class="max-w-7xl mx-auto px-4 lg:px-8 py-3">
            <div class="flex items-center justify-between">
                
                <!-- Logo -->
                <div class="site-branding flex items-center gap-3">
                    <?php if (has_custom_logo()) : ?>
                        <?php the_custom_logo(); ?>
                    <?php else : ?>
                        <a href="<?php echo esc_url(home_url('/')); ?>" class="flex items-center gap-3 select-none text-decoration-none">
                            <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 p-[2px] shadow-md shadow-amber-500/20">
                                <div class="w-full h-full bg-[#0F172A] rounded-[10px] flex items-center justify-center text-amber-400">
                                    <i data-lucide="building-2" class="w-5 h-5"></i>
                                </div>
                            </div>
                            <div class="flex flex-col">
                                <div class="flex items-center gap-1.5">
                                    <span class="text-xl font-black tracking-tight text-slate-900 font-sans">المركز</span>
                                    <span class="text-xl font-black tracking-tight text-amber-600 font-sans">المالي</span>
                                </div>
                                <span class="text-[10px] text-slate-500 font-semibold"><?php bloginfo('description'); ?></span>
                            </div>
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Navigation Menu -->
                <nav id="site-navigation" class="main-navigation hidden lg:flex items-center gap-7 text-sm font-bold text-slate-700">
                    <?php
                    if (has_nav_menu('primary')) {
                        wp_nav_menu(array(
                            'theme_location' => 'primary',
                            'menu_class'     => 'flex items-center gap-7 list-none m-0 p-0',
                            'container'      => false,
                            'fallback_cb'    => false,
                        ));
                    } else {
                        ?>
                        <a href="#tasi" class="text-amber-600 font-black"><?php esc_html_e('الرئيسية', 'financial-center'); ?></a>
                        <a href="#markets" class="hover:text-amber-600 transition-colors"><?php esc_html_e('الأسواق', 'financial-center'); ?></a>
                        <a href="#chart" class="hover:text-amber-600 transition-colors"><?php esc_html_e('التحليل الفني', 'financial-center'); ?></a>
                        <a href="#sectors" class="hover:text-amber-600 transition-colors"><?php esc_html_e('القطاعات', 'financial-center'); ?></a>
                        <a href="#news" class="hover:text-amber-600 transition-colors"><?php esc_html_e('الأخبار', 'financial-center'); ?></a>
                        <?php
                    }
                    ?>
                </nav>

                <!-- Actions -->
                <div class="flex items-center gap-2.5">
                    <button class="fc-quick-trade-btn px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-md transition-all cursor-pointer">
                        <?php esc_html_e('تداول تجريبي ($100k)', 'financial-center'); ?>
                    </button>
                </div>

            </div>
        </div>

    </header>
