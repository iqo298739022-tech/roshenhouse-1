<?php
/**
 * Financial Center Theme Functions and definitions
 *
 * @package Financial_Center
 * @version 2.5.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

define('FINANCIAL_CENTER_VERSION', '2.5.0');
define('FINANCIAL_CENTER_DIR', get_template_directory());
define('FINANCIAL_CENTER_URI', get_template_directory_uri());

/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function financial_center_setup() {
    // Add default posts and comments RSS feed links to head.
    add_theme_support('automatic-feed-links');

    // Let WordPress manage the document title.
    add_theme_support('title-tag');

    // Enable support for Post Thumbnails on posts and pages.
    add_theme_support('post-thumbnails');

    // Custom Logo support
    add_theme_support('custom-logo', array(
        'height'      => 60,
        'width'       => 240,
        'flex-width'  => true,
        'flex-height' => true,
    ));

    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('القائمة الرئيسية - Primary Menu', 'financial-center'),
        'footer'  => __('قائمة التذييل - Footer Menu', 'financial-center'),
    ));

    // Switch default core markup for search form, comment form, etc.
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));

    // Load theme textdomain
    load_theme_textdomain('financial-center', FINANCIAL_CENTER_DIR . '/languages');
}
add_action('after_setup_theme', 'financial_center_setup');

/**
 * Enqueue scripts and styles.
 */
function financial_center_scripts() {
    // Google Fonts: Cairo, Tajawal, IBM Plex Sans Arabic & JetBrains Mono
    wp_enqueue_style(
        'financial-center-fonts',
        'https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800;900&family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&family=Tajawal:wght@300;400;500;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap',
        array(),
        null
    );

    // Theme main stylesheet
    wp_enqueue_style('financial-center-style', get_stylesheet_uri(), array(), FINANCIAL_CENTER_VERSION);

    // Enqueue RTL style if needed
    if (is_rtl()) {
        wp_enqueue_style('financial-center-rtl', FINANCIAL_CENTER_URI . '/rtl.css', array('financial-center-style'), FINANCIAL_CENTER_VERSION);
    }

    // Lucide Icons CDN
    wp_enqueue_script(
        'lucide-icons',
        'https://unpkg.com/lucide@latest',
        array(),
        null,
        true
    );

    // Standalone Market Engine & Interactive Charts JS
    wp_enqueue_script(
        'financial-center-engine',
        FINANCIAL_CENTER_URI . '/assets/js/market-app.js',
        array('jquery'),
        FINANCIAL_CENTER_VERSION,
        true
    );

    // Localize script with REST API endpoints & localized strings
    wp_localize_script('financial-center-engine', 'FinancialCenterData', array(
        'ajaxUrl'    => admin_url('admin-ajax.php'),
        'restUrl'    => esc_url_raw(rest_url('financial-center/v1/')),
        'nonce'      => wp_create_nonce('wp_rest'),
        'siteName'   => get_bloginfo('name'),
        'isRtl'      => is_rtl(),
        'demoBalance'=> 100000,
    ));
}
add_action('wp_enqueue_scripts', 'financial_center_scripts');

/**
 * Include modular theme files
 */
require_once FINANCIAL_CENTER_DIR . '/inc/custom-post-types.php';
require_once FINANCIAL_CENTER_DIR . '/inc/shortcodes.php';
require_once FINANCIAL_CENTER_DIR . '/inc/rest-api.php';
require_once FINANCIAL_CENTER_DIR . '/inc/api-handlers.php';
require_once FINANCIAL_CENTER_DIR . '/inc/customizer.php';
