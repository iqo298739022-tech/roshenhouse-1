<?php
/**
 * The footer for Financial Center theme
 *
 * @package Financial_Center
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

    <footer id="colophon" class="site-footer w-full bg-[#0F172A] text-slate-300 text-xs mt-12 pt-12 pb-8 border-t border-slate-800">
        <div class="max-w-7xl mx-auto px-4 lg:px-8">
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8 mb-12">
                
                <div class="lg:col-span-2 space-y-4">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 p-[2px]">
                            <div class="w-full h-full bg-[#0F172A] rounded-[10px] flex items-center justify-center text-amber-400">
                                <i data-lucide="building-2" class="w-5 h-5"></i>
                            </div>
                        </div>
                        <div>
                            <div class="flex items-center gap-1.5 font-sans font-black text-xl">
                                <span class="text-white"><?php esc_html_e('المركز', 'financial-center'); ?></span>
                                <span class="text-amber-400"><?php esc_html_e('المالي', 'financial-center'); ?></span>
                            </div>
                            <span class="text-[10px] text-slate-400 block font-sans"><?php esc_html_e('أسواق مالية • بيانات وأسعار مباشرة', 'financial-center'); ?></span>
                        </div>
                    </div>

                    <p class="text-slate-400 text-xs leading-relaxed max-w-sm">
                        <?php esc_html_e('قالب ووردبريس متكامل لتقديم الأسعار الحية المباشرة والتحليلات الفنية لأسواق الأسهم السعودية والخليجية والعالمية، السلع، المعادن والعملات الرقمية.', 'financial-center'); ?>
                    </p>
                </div>

                <div>
                    <h4 class="font-bold text-white text-sm mb-3"><?php esc_html_e('الأسواق', 'financial-center'); ?></h4>
                    <ul class="space-y-2 text-slate-400 list-none p-0 m-0">
                        <li><a href="#tasi" class="hover:text-amber-400 transition-colors"><?php esc_html_e('الأسهم السعودية (تاسي)', 'financial-center'); ?></a></li>
                        <li><a href="#commodities" class="hover:text-amber-400 transition-colors"><?php esc_html_e('السلع والمعادن والذهب', 'financial-center'); ?></a></li>
                        <li><a href="#crypto" class="hover:text-amber-400 transition-colors"><?php esc_html_e('العملات الرقمية', 'financial-center'); ?></a></li>
                    </ul>
                </div>

                <div>
                    <h4 class="font-bold text-white text-sm mb-3"><?php esc_html_e('الأدوات', 'financial-center'); ?></h4>
                    <ul class="space-y-2 text-slate-400 list-none p-0 m-0">
                        <li><a href="#calendar" class="hover:text-amber-400 transition-colors"><?php esc_html_e('التقويم الاقتصادي', 'financial-center'); ?></a></li>
                        <li><a href="#analysis" class="hover:text-amber-400 transition-colors"><?php esc_html_e('التحليل الفني', 'financial-center'); ?></a></li>
                        <li><a href="#watchlist" class="hover:text-amber-400 transition-colors"><?php esc_html_e('قوائم المتابعة', 'financial-center'); ?></a></li>
                    </ul>
                </div>

                <div>
                    <h4 class="font-bold text-white text-sm mb-3"><?php esc_html_e('تعليم', 'financial-center'); ?></h4>
                    <ul class="space-y-2 text-slate-400 list-none p-0 m-0">
                        <li><a href="#academy" class="hover:text-amber-400 transition-colors"><?php esc_html_e('أكاديمية التداول', 'financial-center'); ?></a></li>
                        <li><a href="#lessons" class="hover:text-amber-400 transition-colors"><?php esc_html_e('الدروس التعليمية', 'financial-center'); ?></a></li>
                    </ul>
                </div>

                <div>
                    <h4 class="font-bold text-white text-sm mb-3"><?php esc_html_e('عن المنصة', 'financial-center'); ?></h4>
                    <ul class="space-y-2 text-slate-400 list-none p-0 m-0">
                        <li><a href="#about" class="hover:text-amber-400 transition-colors"><?php esc_html_e('عن المركز المالي', 'financial-center'); ?></a></li>
                        <li><a href="#contact" class="hover:text-amber-400 transition-colors"><?php esc_html_e('اتصل بنا', 'financial-center'); ?></a></li>
                    </ul>
                </div>

            </div>

            <div class="pt-6 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4 text-slate-500 text-[11px]">
                <div>
                    <?php printf(esc_html__('جميع الحقوق محفوظة © %s المركز المالي (Financial Center). قالب ووردبريس للأسواق المالية.', 'financial-center'), date('Y')); ?>
                </div>
                <div class="flex items-center gap-4 text-slate-400">
                    <span><?php esc_html_e('سياسة الخصوصية', 'financial-center'); ?></span>
                    <span>•</span>
                    <span><?php esc_html_e('شروط الاستخدام', 'financial-center'); ?></span>
                </div>
            </div>

        </div>
    </footer>

</div><!-- #page -->

<?php wp_footer(); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        if (window.lucide) {
            window.lucide.createIcons();
        }
    });
</script>
</body>
</html>
