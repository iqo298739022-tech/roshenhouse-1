<?php
/**
 * The Front Page template for Financial Center Theme
 *
 * @package Financial_Center
 * @version 2.5.0
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

// Fetch cached live quotes if available from Twelve Data / CoinGecko
$live_quotes = function_exists('financial_center_fetch_live_quotes') ? financial_center_fetch_live_quotes() : array();
?>

<main id="primary" class="site-main w-full max-w-7xl mx-auto px-4 lg:px-8 py-5 space-y-6">

    <!-- 1. شريط الأخبار والأسعار المتحرك المباشر (Live Marquee Ticker) -->
    <div class="w-full bg-[#0F172A] rounded-2xl overflow-hidden text-xs text-white border border-slate-800 shadow-sm mb-4">
        <div class="flex items-center">
            <div class="z-20 flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black shrink-0 shadow-md">
                <span class="w-2 h-2 rounded-full bg-red-600 live-dot-red shrink-0"></span>
                <span class="text-[11px] font-bold">بث مباشر ⚡</span>
            </div>
            <div class="flex-1 overflow-hidden py-1.5 whitespace-nowrap">
                <div class="fc-ticker-marquee inline-flex items-center gap-6 font-mono text-xs">
                    <span class="inline-flex items-center gap-1 bg-slate-800/80 px-2.5 py-1 rounded-lg">🇸🇦 تاسي: <strong class="text-white">11,516.68</strong> <span class="text-emerald-400 font-bold">+0.22%</span></span>
                    <span class="inline-flex items-center gap-1 bg-slate-800/80 px-2.5 py-1 rounded-lg">🛢️ أرامكو: <strong class="text-white">222.60</strong> <span class="text-emerald-400 font-bold">+0.18%</span></span>
                    <span class="inline-flex items-center gap-1 bg-slate-800/80 px-2.5 py-1 rounded-lg">🪙 الذهب: <strong class="text-white">$2,345.60</strong> <span class="text-emerald-400 font-bold">+0.53%</span></span>
                    <span class="inline-flex items-center gap-1 bg-slate-800/80 px-2.5 py-1 rounded-lg">⛽ خام برنت: <strong class="text-white">$83.45</strong> <span class="text-rose-400 font-bold">-0.43%</span></span>
                    <span class="inline-flex items-center gap-1 bg-slate-800/80 px-2.5 py-1 rounded-lg">₿ بيتكوين: <strong class="text-white">$66,854.20</strong> <span class="text-emerald-400 font-bold">+1.83%</span></span>
                    <span class="inline-flex items-center gap-1 bg-slate-800/80 px-2.5 py-1 rounded-lg">💎 الفضة: <strong class="text-white">$27.85</strong> <span class="text-emerald-400 font-bold">+0.54%</span></span>
                    <span class="inline-flex items-center gap-1 bg-slate-800/80 px-2.5 py-1 rounded-lg">🏦 الراجحي: <strong class="text-white">88.70</strong> <span class="text-rose-400 font-bold">-0.22%</span></span>
                </div>
            </div>
        </div>
    </div>

    <!-- 2. بطاقات المؤشرات الستة الكبرى (Market Ribbon) -->
    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div class="fc-card p-3.5 bg-white hover:bg-slate-50 transition-all cursor-pointer border border-slate-200">
            <div class="flex justify-between items-center mb-1">
                <span class="text-xs font-bold text-slate-800">تاسي (TASI)</span>
                <span class="text-[10px] text-slate-400">🇸🇦</span>
            </div>
            <div class="text-sm font-black font-mono text-slate-900">11,516.68</div>
            <div class="text-[11px] font-bold text-emerald-600 font-mono">+25.74 (+0.22%)</div>
        </div>

        <div class="fc-card p-3.5 bg-white hover:bg-slate-50 transition-all cursor-pointer border border-slate-200">
            <div class="flex justify-between items-center mb-1">
                <span class="text-xs font-bold text-slate-800">مؤشر دبي (DFM)</span>
                <span class="text-[10px] text-slate-400">🇦🇪</span>
            </div>
            <div class="text-sm font-black font-mono text-slate-900">4,091.53</div>
            <div class="text-[11px] font-bold text-rose-600 font-mono">-6.21 (-0.15%)</div>
        </div>

        <div class="fc-card p-3.5 bg-white hover:bg-slate-50 transition-all cursor-pointer border border-slate-200">
            <div class="flex justify-between items-center mb-1">
                <span class="text-xs font-bold text-slate-800">الذهب (XAU/USD)</span>
                <span class="text-[10px] text-slate-400">🪙</span>
            </div>
            <div class="text-sm font-black font-mono text-slate-900">$2,345.60</div>
            <div class="text-[11px] font-bold text-emerald-600 font-mono">+12.45 (+0.53%)</div>
        </div>

        <div class="fc-card p-3.5 bg-white hover:bg-slate-50 transition-all cursor-pointer border border-slate-200">
            <div class="flex justify-between items-center mb-1">
                <span class="text-xs font-bold text-slate-800">خام برنت (Brent)</span>
                <span class="text-[10px] text-slate-400">🛢️</span>
            </div>
            <div class="text-sm font-black font-mono text-slate-900">$83.45</div>
            <div class="text-[11px] font-bold text-rose-600 font-mono">-0.36 (-0.43%)</div>
        </div>

        <div class="fc-card p-3.5 bg-white hover:bg-slate-50 transition-all cursor-pointer border border-slate-200">
            <div class="flex justify-between items-center mb-1">
                <span class="text-xs font-bold text-slate-800">الفضة (Silver)</span>
                <span class="text-[10px] text-slate-400">💎</span>
            </div>
            <div class="text-sm font-black font-mono text-slate-900">$27.85</div>
            <div class="text-[11px] font-bold text-emerald-600 font-mono">+0.15 (+0.54%)</div>
        </div>

        <div class="fc-card p-3.5 bg-white hover:bg-slate-50 transition-all cursor-pointer border border-slate-200">
            <div class="flex justify-between items-center mb-1">
                <span class="text-xs font-bold text-slate-800">بيتكوين (BTC)</span>
                <span class="text-[10px] text-slate-400">₿</span>
            </div>
            <div class="text-sm font-black font-mono text-slate-900">$66,854.20</div>
            <div class="text-[11px] font-bold text-emerald-600 font-mono">+1,203.45 (+1.83%)</div>
        </div>
    </div>

    <!-- 3. منطقة التداول الرئيسية: الرسم البياني الكبير (8 أعمدة) + قائمة المتابعة في أعلى اليسار (4 أعمدة) -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        
        <!-- قائمة المتابعة الحية في أعلى اليسار (4 أعمدة) -->
        <div class="lg:col-span-4 order-2 lg:order-1">
            <div class="fc-card border-2 border-slate-200">
                <div class="p-4 bg-gradient-to-r from-[#0F172A] via-[#1E293B] to-[#0F172A] text-white flex items-center justify-between">
                    <div class="flex items-center gap-2">
                        <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 live-dot-green"></span>
                        <h3 class="text-base font-black text-white"><?php esc_html_e('قائمة المتابعة الحية', 'financial-center'); ?></h3>
                    </div>
                    <span class="text-xs bg-amber-500 text-slate-950 font-bold px-2 py-0.5 rounded-full">10 أصول</span>
                </div>

                <div class="p-2 bg-slate-50 border-b border-slate-200 flex gap-1 text-xs font-bold overflow-x-auto">
                    <button class="px-2.5 py-1 bg-[#0F172A] text-white rounded-lg"><?php esc_html_e('الكل', 'financial-center'); ?></button>
                    <button class="px-2.5 py-1 bg-white border border-slate-200 text-slate-700 rounded-lg"><?php esc_html_e('الأسهم 🇸🇦', 'financial-center'); ?></button>
                    <button class="px-2.5 py-1 bg-white border border-slate-200 text-slate-700 rounded-lg"><?php esc_html_e('الكريبتو 🪙', 'financial-center'); ?></button>
                    <button class="px-2.5 py-1 bg-white border border-slate-200 text-slate-700 rounded-lg"><?php esc_html_e('السلع 🛢️', 'financial-center'); ?></button>
                </div>

                <div class="divide-y divide-slate-100 max-h-[480px] overflow-y-auto font-mono text-xs">
                    <div class="p-3 hover:bg-slate-50 flex items-center justify-between cursor-pointer">
                        <div>
                            <span class="font-sans font-bold text-slate-900 block">أرامكو السعودية</span>
                            <span class="text-[10px] text-slate-400">2222.SR</span>
                        </div>
                        <div class="text-left font-black text-slate-900">222.60 <span class="text-emerald-600 text-[11px] block">+0.18%</span></div>
                    </div>
                    <div class="p-3 hover:bg-slate-50 flex items-center justify-between cursor-pointer">
                        <div>
                            <span class="font-sans font-bold text-slate-900 block">الراجحي</span>
                            <span class="text-[10px] text-slate-400">1120.SR</span>
                        </div>
                        <div class="text-left font-black text-slate-900">88.70 <span class="text-rose-600 text-[11px] block">-0.22%</span></div>
                    </div>
                    <div class="p-3 hover:bg-slate-50 flex items-center justify-between cursor-pointer">
                        <div>
                            <span class="font-sans font-bold text-slate-900 block">الاتصالات (STC)</span>
                            <span class="text-[10px] text-slate-400">7010.SR</span>
                        </div>
                        <div class="text-left font-black text-slate-900">25.65 <span class="text-emerald-600 text-[11px] block">+0.59%</span></div>
                    </div>
                    <div class="p-3 hover:bg-slate-50 flex items-center justify-between cursor-pointer">
                        <div>
                            <span class="font-sans font-bold text-slate-900 block">البنك الأهلي (SNB)</span>
                            <span class="text-[10px] text-slate-400">1180.SR</span>
                        </div>
                        <div class="text-left font-black text-slate-900">37.90 <span class="text-rose-600 text-[11px] block">-0.26%</span></div>
                    </div>
                    <div class="p-3 hover:bg-slate-50 flex items-center justify-between cursor-pointer">
                        <div>
                            <span class="font-sans font-bold text-slate-900 block">سابك</span>
                            <span class="text-[10px] text-slate-400">2010.SR</span>
                        </div>
                        <div class="text-left font-black text-slate-900">78.40 <span class="text-emerald-600 text-[11px] block">+0.77%</span></div>
                    </div>
                    <div class="p-3 hover:bg-slate-50 flex items-center justify-between cursor-pointer">
                        <div>
                            <span class="font-sans font-bold text-slate-900 block">بيتكوين</span>
                            <span class="text-[10px] text-slate-400">BTC/USD</span>
                        </div>
                        <div class="text-left font-black text-slate-900">$66,854.20 <span class="text-emerald-600 text-[11px] block">+1.83%</span></div>
                    </div>
                    <div class="p-3 hover:bg-slate-50 flex items-center justify-between cursor-pointer">
                        <div>
                            <span class="font-sans font-bold text-slate-900 block">الذهب</span>
                            <span class="text-[10px] text-slate-400">XAU/USD</span>
                        </div>
                        <div class="text-left font-black text-slate-900">$2,345.60 <span class="text-emerald-600 text-[11px] block">+0.53%</span></div>
                    </div>
                </div>

                <div class="p-3 border-t border-slate-200 bg-slate-50">
                    <button class="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 text-slate-950 font-black text-xs shadow-md border border-amber-400">
                        <?php esc_html_e('إدارة وتخصيص قائمة المتابعة', 'financial-center'); ?>
                    </button>
                </div>
            </div>
        </div>

        <!-- الرسم البياني الكبير التفاعلي (8 أعمدة) -->
        <div class="lg:col-span-8 order-1 lg:order-2 space-y-4">
            <div id="fc-interactive-chart-card" class="fc-card border-2 border-slate-200 overflow-hidden">
                <div class="p-4 sm:p-5 bg-gradient-to-r from-[#0F172A] via-[#1E293B] to-[#0F172A] text-white flex flex-wrap items-center justify-between gap-4">
                    <div class="flex items-center gap-3">
                        <div class="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-amber-400 text-lg">
                            🇸🇦
                        </div>
                        <div>
                            <div class="flex items-center gap-2">
                                <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 live-dot-green"></span>
                                <h2 class="text-xl font-black text-white">المؤشر العام السعودي (TASI)</h2>
                                <span class="text-xs bg-slate-800 text-amber-300 font-mono font-bold px-2 py-0.5 rounded">TASI</span>
                            </div>
                            <div class="text-3xl font-black font-mono text-white mt-1">11,516.68 <span class="text-xs text-slate-300 font-sans">نقطة</span> <span class="text-sm text-emerald-400 font-bold mr-2">+25.74 (+0.22%)</span></div>
                        </div>
                    </div>

                    <div class="flex items-center gap-1.5 bg-slate-800 p-1 rounded-xl text-xs font-bold">
                        <button class="px-3 py-1 bg-amber-500 text-slate-950 rounded-lg">1D</button>
                        <button class="px-3 py-1 text-slate-300 hover:text-white">1W</button>
                        <button class="px-3 py-1 text-slate-300 hover:text-white">1M</button>
                        <button class="px-3 py-1 text-slate-300 hover:text-white">1Y</button>
                        <button class="px-3 py-1 text-slate-300 hover:text-white">ALL</button>
                    </div>
                </div>

                <!-- SVG Interactive Chart Container -->
                <div class="p-4 bg-gradient-to-b from-slate-50/50 to-white min-h-[320px] flex items-center justify-center">
                    <svg viewBox="0 0 840 320" class="w-full h-auto">
                        <defs>
                            <linearGradient id="wpAreaGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                                <stop offset="0%" stopColor="#2563EB" stopOpacity="0.25" />
                                <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0.0" />
                            </linearGradient>
                        </defs>
                        <!-- Chart path -->
                        <path d="M 30 250 L 110 220 L 190 235 L 280 180 L 370 195 L 460 140 L 550 160 L 640 90 L 730 110 L 810 50" fill="none" stroke="#2563EB" stroke-width="3" stroke-linecap="round" />
                        <path d="M 30 250 L 110 220 L 190 235 L 280 180 L 370 195 L 460 140 L 550 160 L 640 90 L 730 110 L 810 50 L 810 290 L 30 290 Z" fill="url(#wpAreaGrad)" />
                        <!-- Grid lines -->
                        <line x1="30" y1="50" x2="810" y2="50" stroke="#E2E8F0" stroke-dasharray="3 3" />
                        <line x1="30" y1="120" x2="810" y2="120" stroke="#E2E8F0" stroke-dasharray="3 3" />
                        <line x1="30" y1="190" x2="810" y2="190" stroke="#E2E8F0" stroke-dasharray="3 3" />
                        <line x1="30" y1="260" x2="810" y2="260" stroke="#E2E8F0" stroke-dasharray="3 3" />
                        <!-- Latest price dot -->
                        <circle cx="810" cy="50" r="6" fill="#16A34A" stroke="#FFFFFF" stroke-width="2" />
                    </svg>
                </div>

                <div class="p-4 border-t border-slate-100 flex items-center justify-between bg-slate-50/50">
                    <div class="flex items-center gap-2">
                        <button class="px-6 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs"><?php esc_html_e('شراء فوري', 'financial-center'); ?></button>
                        <button class="px-6 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs"><?php esc_html_e('بيع فوري', 'financial-center'); ?></button>
                    </div>
                    <span class="text-xs font-mono text-slate-500">نطاق 52 أسبوع: 10,250.20 - 11,650.20</span>
                </div>
            </div>
        </div>

    </div>

    <!-- 4. مؤشرات التوصيات والزخم الفني المباشرة الثلاثية (على طول الموقع) -->
    <div class="w-full fc-card border-2 border-slate-200">
        <div class="p-4 sm:p-5 bg-gradient-to-r from-[#0F172A] via-[#1E293B] to-[#0F172A] text-white flex items-center justify-between">
            <div class="flex items-center gap-2.5">
                <span class="w-3 h-3 rounded-full bg-emerald-400 live-dot-green"></span>
                <h2 class="text-base sm:text-lg font-black text-white"><?php esc_html_e('مؤشرات التوصيات والزخم الفني المباشرة (شراء / بيع)', 'financial-center'); ?></h2>
            </div>
            <span class="text-xs bg-amber-500/20 text-amber-300 px-3 py-1 rounded-full font-bold">تحليل فني ثلاثي الأبعاد</span>
        </div>

        <div class="p-5 grid grid-cols-1 md:grid-cols-3 gap-5 bg-white">
            <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-center">
                <span class="text-xs font-bold text-slate-600 block mb-1">1. إجماع المحللين</span>
                <div class="text-xl font-black text-emerald-600 my-2">شراء قوي 🟢</div>
                <div class="text-xs font-mono text-slate-500">80% شراء • 15% محايد • 5% بيع</div>
            </div>

            <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-center">
                <span class="text-xs font-bold text-slate-600 block mb-1">2. مؤشر الزخم (RSI 14)</span>
                <div class="text-xl font-black text-blue-600 my-2">زخم صاعد إيجابي (68.5)</div>
                <div class="text-xs font-mono text-slate-500">12 إشارة صاعدة • MACD +1.45</div>
            </div>

            <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-center">
                <span class="text-xs font-bold text-slate-600 block mb-1">3. تدفق السيولة</span>
                <div class="text-xl font-black text-amber-600 my-2">طمع شرائي وتجميع (%76)</div>
                <div class="text-xs font-mono text-slate-500">تدفقات داخلة 76% • خارجة 24%</div>
            </div>
        </div>
    </div>

    <!-- 5. مربعات الأكثر ارتفاعاً، الأكثر انخفاضاً، والسلع -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="fc-card border border-slate-200 p-4">
            <h3 class="font-bold text-sm text-slate-900 mb-3 flex items-center gap-1.5"><span class="text-emerald-600">▲</span> الأكثر ارتفاعاً (Top Gainers)</h3>
            <div class="space-y-2 text-xs font-mono">
                <div class="flex justify-between"><span>البحر الأحمر (4230)</span><strong class="text-emerald-600">+7.27%</strong></div>
                <div class="flex justify-between"><span>معادن (1211)</span><strong class="text-emerald-600">+6.20%</strong></div>
                <div class="flex justify-between"><span>أكوا باور (2082)</span><strong class="text-emerald-600">+5.10%</strong></div>
            </div>
        </div>

        <div class="fc-card border border-slate-200 p-4">
            <h3 class="font-bold text-sm text-slate-900 mb-3 flex items-center gap-1.5"><span class="text-rose-600">▼</span> الأكثر انخفاضاً (Top Losers)</h3>
            <div class="space-y-2 text-xs font-mono">
                <div class="flex justify-between"><span>دار الأركان (4300)</span><strong class="text-rose-600">-6.15%</strong></div>
                <div class="flex justify-between"><span>الإنماء (1150)</span><strong class="text-rose-600">-4.35%</strong></div>
                <div class="flex justify-between"><span>التعمير (4150)</span><strong class="text-rose-600">-3.60%</strong></div>
            </div>
        </div>

        <div class="fc-card border border-slate-200 p-4">
            <h3 class="font-bold text-sm text-slate-900 mb-3 flex items-center gap-1.5"><span class="text-amber-500">🛢️</span> السلع والمعادن (Commodities)</h3>
            <div class="space-y-2 text-xs font-mono">
                <div class="flex justify-between"><span>خام برنت ($83.45)</span><strong class="text-rose-600">-0.43%</strong></div>
                <div class="flex justify-between"><span>الذهب ($2,345.60)</span><strong class="text-emerald-600">+0.53%</strong></div>
                <div class="flex justify-between"><span>الفضة ($27.85)</span><strong class="text-emerald-600">+0.54%</strong></div>
            </div>
        </div>
    </div>

    <!-- 6. مركز قطاعات السوق السعودي (تاسي) في الوسط مع إطارات خفيفة -->
    <div class="fc-card border-2 border-slate-200 p-5">
        <h3 class="font-black text-base text-slate-900 mb-3"><?php esc_html_e('أداء قطاعات السوق المالي السعودي (تاسي)', 'financial-center'); ?></h3>
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            <div class="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <div class="flex justify-between font-bold"><span>قطاع البنوك</span><span class="text-emerald-600">+0.45%</span></div>
                <div class="text-[10px] text-slate-400 mt-1">السيولة: 1.85B ر.س</div>
            </div>
            <div class="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <div class="flex justify-between font-bold"><span>قطاع الطاقة</span><span class="text-emerald-600">+0.18%</span></div>
                <div class="text-[10px] text-slate-400 mt-1">السيولة: 980M ر.س</div>
            </div>
            <div class="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <div class="flex justify-between font-bold"><span>المواد الأساسية</span><span class="text-emerald-600">+1.42%</span></div>
                <div class="text-[10px] text-slate-400 mt-1">السيولة: 1.42B ر.س</div>
            </div>
            <div class="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <div class="flex justify-between font-bold"><span>المرافق العامة</span><span class="text-emerald-600">+3.85%</span></div>
                <div class="text-[10px] text-slate-400 mt-1">السيولة: 780M ر.س</div>
            </div>
            <div class="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <div class="flex justify-between font-bold"><span>الاتصالات</span><span class="text-emerald-600">+0.59%</span></div>
                <div class="text-[10px] text-slate-400 mt-1">السيولة: 420M ر.س</div>
            </div>
        </div>
    </div>

</main>

<?php
get_footer();
